
class Canvas{
    constructor(id){
        this.c = document.getElementById(id);
        this.ctx = this.c.getContext("2d");
        this.colores = ["#009AFC", "#15A630","#FFE328","#F15B00","#D60000"];
    }

}
